# 4I200_MOGPL-projet
[fr] Projet de l'UE MOGPL [4I200]


## Idées
* Créer un package pip (trouver un nom)

solve <CONSTRAINTS_FILE> --method DYNAMIC | LINEAR | BOTH

