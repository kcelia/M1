# -*- coding: utf-8 -*-
from __future__ import print_function
import solveurs.dynamic_programming as dp
#import solveurs.linear_programming as lp
from grille.parser import parse_instance
from grille.affichage import affiche_grille
from grille.grille_utils import verifie_grille


NOMBRE_INSTANCES = 17
INSTANCE_PATTERN = "../instances/{index}.txt"


def main():
    for instance_index in range(2, 3):
        file_path = INSTANCE_PATTERN.format(index=instance_index)
        contraintes_lignes, contraintes_colonnes = parse_instance(file_path)
        print("Instance :", instance_index)

        grille1, temps = dp.resoudre_dynamique(
            contraintes_lignes, contraintes_colonnes)
        print("Temps total                   :", temps)
        print("La grille est bien résolue    :", verifie_grille(
            grille1, contraintes_lignes, contraintes_colonnes))
        print("")

        # grille2, temps_lineaire, temps_dynamique = lp.resoudre_linear(contraintes_lignes, contraintes_colonnes, propagation=True)
        # print("Temps programmation dynamique :", temps_dynamique)
        # print("Temps programmation linéaire  :", temps_lineaire)
        # print("Temps total                   :", temps_dynamique + temps_lineaire)
        # print("La grille est bien résolue    :", verifie_grille(grille2, contraintes_lignes, contraintes_colonnes))
        # print("\n\n")

        affiche_grille(grille1, "Instance {index}, DP".format(
                       index=instance_index))
        # affiche_grille(grille2, "Instance {index}, LP".format(
        #                index=instance_index))


if __name__ == '__main__':
    main()
