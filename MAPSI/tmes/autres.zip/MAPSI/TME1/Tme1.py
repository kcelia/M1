# -*- coding: utf-8 -*-
"""
Éditeur de Spyder

Ceci est un script temporaire.
"""
import numpy as np 


#application 1
v1 = np.array([np.arange(1,11,1)])
v1=v1.T
v2 = np.random.rand(1,10)
v2 = v2.T
v3 = np.zeros((1,10))
v3 =v3.T

c = np.arange(1,4,1) 
v = np.hstack((v1,v2,v3))
v = np.vstack((c,v))
#application 2
notes = np.loadtxt('college1.dat')

#application3
import random

matrice = np.array( [ [random.randint(1,100) if  (i + j)%2 == 0 else i+j for i in range(10) ] for j in range(10) ])


#application 4
import matplotlib.pyplot as plt 

#data = np.loadtxt("salaire2010INSEE.csv", delimiter = ';')
#diplomes = ["Aucun", "BEPC", "CAP/BEP", "Bac", "IUT, BTS, DEUG", ">Bac+2", "Master/Phd", "Ecole Ing/com"]
#len(diplomes)
#dip = [ i for i in range(8)]
#dip
#
#fig = plt.figure() # astuce: récupération d'un pointeur pour pouvoir modifier
#p = fig.add_subplot(111)
#
#diplomes = ["Aucun", "BEPC", "CAP/BEP", "Bac", "IUT, BTS, DEUG", ">Bac+2", "Master/Phd", "Ecole Ing/com"]

#p.set_xticks(np.arange(data.shape[0])) # où positionner les étiquettes
#lab = p.set_xticklabels(diplomes) 
#plt.xlabel(U"Diplome", fontsize=10)
#plt.setp(lab, rotation=45, fontsize=10)
#plt.scatter(data[:,0],dip, c = 'green')
#plt.show()
#fig = plt.figure() 
#plt.scatter(data[:,3],dip, c = 'pink')
#fig = plt.figure() 
#plt.show()
#plt.scatter(data[:,5],dip, c = 'blue')
#plt.show()

# Velib
import pickle as pkl
fname = "velib.pkl"
f= open(fname,'rb')
data = pkl.load(f)
f.close()