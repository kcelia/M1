# -*- coding: utf-8 -*-
"""
    TME 9
"""

import numpy as np
import numpy.random as npr
import matplotlib.pyplot as plt
import pickle as pkl

# Estimation de pi par Monte Carlo

def tirage( m ):
    """
        float -> float x float
        m : nombre reel
        Retourne un point tire aleatoirement selon la loi uniforme 
        dans le carre [-m, m] x [-m, m]
    """
    x = npr.uniform(-m, m)
    y = npr.uniform(-m, m)
    return (x, y)
    
def monteCarlo( N ):
    """
        int -> float x float np.array x float np.array
        N : nombre de tirages
        Retourne un triplet compose d'une estimation de pi par Monte Carlo
        ainsi que du tableau des N abscisses et du tableau des N ordonnees qui
        ont permis d'obtenir cette estimation
    """
    x = []
    y = []
    cpt = 0 # compteur du nombre de points dans le quart de disque de rayon 1
    for i in range ( N ):
        a, b = tirage( 1 )
        x.append(a)
        y.append(b)
        if (a*a + b*b) <= 1:
            cpt += 1
    x = np.array(x, float) 
    y = np.array(y, float)
    return (4.*cpt)/N, x, y

def dessin():
    plt.figure()

    # trace le carré
    plt.plot([-1, -1, 1, 1], [-1, 1, 1, -1], '-')

    # trace le cercle
    x = np.linspace(-1, 1, 100)
    y = np.sqrt(1- x*x)
    plt.plot(x, y, 'b')
    plt.plot(x, -y, 'b')

    # estimation par Monte Carlo
    pi, x, y = monteCarlo(int(1e4))

    # trace les points dans le cercle et hors du cercle
    dist = x*x + y*y
    plt.plot(x[dist <=1], y[dist <=1], "go")
    plt.plot(x[dist>1], y[dist>1], "ro")
    plt.show()

#dessin()


# Decodage par la methode de Metropolis-Hastings

def loadData( filename_pkl, filename_txt ):
    """
        charge les donnees
    """
    with open(filename_pkl, 'rb') as f:
        (count, mu, A) = pkl.load(f, encoding='latin1')
    secret = (open(filename_txt, "r")).read()[0:-1] # -1 pour supprimer le saut de ligne
    return count, mu, A, secret

count, mu, A, secret = loadData("countWar.pkl", "secret2.txt")

def swapF( tau_t ):
    """
        (char, char)dict -> (char, char)dict
        tau = fonction de decodage
        Retourne une nouvelle fonction de decodage tau
        - tau(c) = tau_t(c) pour tout c different de c1 et c different de c2
        - tau(c1) = tau_t(c2)
        - tau(c2) = tau_t(c1)
    """
    np.random.seed()
    tau = dict()
    keys = list(tau_t.keys())
    # on choisit les 2 lettres a echanger
    n1 = npr.randint(0, len(keys))
    n2 = npr.randint(0, len(keys))
    # si c1 == c2
    while( n2 == n1 ):
        n2 = npr.randint(0, len(keys))
    c1 = keys[n1]
    c2 = keys[n2]
    #print("c1 = " + c1)
    #print("c2 = " + c2)
    for c in keys:
        if c == c1:
            tau[c1] = tau_t[c2]
        elif c == c2:
            tau[c2] = tau_t[c1]
        else:
            tau[c] = tau_t[c]
    return tau
    
tau = {'a' : 'b', 'b' : 'c', 'c' : 'a', 'd' : 'd' }
t = swapF(tau)
#print(t)

def decrypt( mess, tau ):
    """
        string x (char, char)dict -> string
        mess : chaine a decoder
        tau : fonction de decodage
        Retourne la chaine de caracteres obtenue par decodage de mess par tau
    """
    msg = ""
    for s in mess:
        msg += tau[s]
    return msg

mess1 = decrypt ( "aabcd", tau )
mess2 = decrypt ( "dcba", tau )
#print(mess1)
#print(mess2)

def logLikelihood( mess, mu, A, chars ):
    """
        string x float np.array x float np.2d-array x char list -> float
        mess : message
        mu : vecteur de probabilites initiales
        A : matrice de transition
        chars : pour obtenir l'indice correspondant a une lettre
        Retourne la log-probabilite du message mess
    """
    chars = list(chars)
    L = [m for m in mess]
    index = chars.index(L[0])
    proba = np.log(mu[index])
    
    for i in range(1, len(L)):
        t = chars.index(L[i-1])
        t_1 = chars.index(L[i])
        proba += np.log(A[t][t_1])
    return proba

p1 = logLikelihood( "abcd", mu, A, count.keys() )
p2 = logLikelihood( "dcba", mu, A, count.keys() )

def MetropolisHastings( mess, mu, A, tau, N ):
    """
        mess : message code
        mu, A : modele de bigrammes
        tau : fonction de decodage initiale
        N : nombre maximum d'iteration de l'algorithme
        Retourne le message decode le plus vraisemblable    
    """
    decode = ""
    for i in range( N ):
        new_tau = swapF(tau)
        msg_tau = decrypt(mess, tau)
        msg_new_tau = decrypt(mess, new_tau)
        log_tau = logLikelihood(msg_tau, mu, A, count.keys())
        log_new_tau = logLikelihood(msg_new_tau, mu, A, count.keys())
        alpha = min(1, log_new_tau/log_tau)
        #print("tau : " +str(log_tau))
        #print("tau' : "+str(log_new_tau))         
        u = np.random.uniform(0, 1)
        if u <= alpha:
            tau = new_tau
            if log_tau < log_new_tau:
                decode = msg_new_tau
                print("log-vraisemblance : " + str(log_new_tau))
            else:
                decode = msg_tau
        
    return decode

def identityTau ():
    tau = {}
    for k in count.keys ():
        tau[k] = k
    return tau

#mh = MetropolisHastings( secret, mu, A, identityTau (), 10 )
#print(mh)



def updateOccurrences(text, count):
   for c in text:
      if c == u'\n':
         continue
      try:
         count[c] += 1
      except KeyError as e:
         count[c] = 1

def mostFrequent(count):
   bestK = []
   bestN = -1
   for k in count.keys():
      if (count[k]>bestN):
         bestK = [k]
         bestN = count[k]
      elif (count[k]==bestN):
         bestK.append(k)
   return bestK

def replaceF(f, kM, k):
   try:
      for c in f.keys():
         if f[c] == k:
            f[c] = f[kM]
            f[kM] = k
            return
   except KeyError as e:
      f[kM] = k

def mostFrequentF(message, count1, f={}):
   count = dict(count1)
   countM = {}
   updateOccurrences(message, countM)
   while len(countM) > 0:
      bestKM = mostFrequent(countM)
      bestK = mostFrequent(count)
      if len(bestKM)==1:
         kM = bestKM[0]
      else:
         kM = bestKM[npr.random_integers(0, len(bestKM)-1)]
      if len(bestK)==1:
         k = bestK[0]
      else:
         k = bestK[npr.random_integers(0, len(bestK)-1)]
      replaceF(f, kM, k)
      countM.pop(kM)
      count.pop(k)
   return f

tau_init = mostFrequentF(secret, count, identityTau () )

mh = MetropolisHastings(secret, mu, A, tau_init, 50000 )
print(mh)